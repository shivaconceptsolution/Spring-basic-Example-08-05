package dao;

import javax.persistence.*;

@Entity
@Table
public class Register {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int id;
@Column
private String emailid;
@Column
private String password;


public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}

}
